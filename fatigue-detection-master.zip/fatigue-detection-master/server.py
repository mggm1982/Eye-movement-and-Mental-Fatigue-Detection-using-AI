#First i make it clear i wrote comments for better understanding
from flask import Flask, request, jsonify
from flask_cors import CORS # Import the CORS library
import joblib
import numpy as np
import os

# Initialize the Flask application
app = Flask(__name__)

# --- FIX: Enable CORS ---
CORS(app)

# --- Load the Trained Model ---
model_path = 'fatigue_model.joblib'
model = None

# Check if the model file exists before trying to load it
if os.path.exists(model_path):
    print("Loading the trained model...")
    model = joblib.load(model_path)
    print("Model loaded successfully.")
else:
    print(f"Error: Model file not found at '{model_path}'.")
    print("Please make sure you have run 'train_model.py' to generate the model file.")


@app.route('/predict', methods=['POST'])
def predict():
    # First, check if the model was loaded correctly.
    if model is None:
        # Return an error response in JSON format
        return jsonify({'error': 'Model is not loaded. Please check server logs.'}), 500

    try:
        # Get the JSON data sent from the client
        data = request.get_json()

        # Extract the features in the correct order our model expects
        features = [
            data['Blink_Rate'],
            data['Avg_Blink_Duration'],
            data['PERCLOS'],
            data['EAR_Variance']
        ]


        final_features = np.array(features).reshape(1, -1)

        # --- Make the Prediction ---
        # The core of the API: use the loaded model to predict the class (0 or 1)
        prediction = model.predict(final_features)

        # Get the result (it will be an array like [0] or [1])
        output = int(prediction[0])

        # Convert the numerical prediction to a human-readable status
        status = 'Alert'
        if output == 1:
            status = 'Fatigued'

        # Return the final result as a JSON response
        return jsonify({'status': status, 'prediction': output})

    except Exception as e:
        return jsonify({'error': str(e)}), 400

if __name__ == '__main__':
    
    app.run(host='0.0.0.0', port=5000)
