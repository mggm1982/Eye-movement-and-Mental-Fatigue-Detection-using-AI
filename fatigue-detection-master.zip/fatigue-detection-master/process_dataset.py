# process_data.py (Updated for numbered folders and files)
# -----------------------------------------------------------------------------
# This script processes a dataset with a specific structure:
# - A main 'Dataset' folder contains subfolders named '01', '02', etc., for each subject.
# - Inside each subject folder, there are videos named '0.mov', '5.mov', and '10.mov'.
# - The script uses the filename to determine the label:
#   - '0.mov' -> Label 0 (Alert)
#   - '10.mov' -> Label 1 (Fatigued)
#   - '5.mov' -> Ignored, as requested.
# -----------------------------------------------------------------------------

import cv2
import mediapipe as mp
import numpy as np
import os
import csv
from collections import deque
from tqdm import tqdm #progress bar

# --- Constants ---
EAR_THRESHOLD = 0.20
EAR_CONSEC_FRAMES = 3
ANALYSIS_WINDOW_SECONDS = 10

#For EAR calculation
def calculate_ear(eye_landmarks):
    v1 = np.linalg.norm(eye_landmarks[1] - eye_landmarks[5])
    v2 = np.linalg.norm(eye_landmarks[2] - eye_landmarks[4])
    h = np.linalg.norm(eye_landmarks[0] - eye_landmarks[3])
    if h == 0:
        return 0
    ear = (v1 + v2) / (2.0 * h)
    return ear

def process_video_segment(ear_values, fps):
    """Calculates features for a given window of EAR values."""
    total_blinks = 0
    total_blink_frames = 0
    blink_counter = 0

    for ear in ear_values:
        if ear != -1 and ear < EAR_THRESHOLD:
            blink_counter += 1
        else:
            if blink_counter >= EAR_CONSEC_FRAMES:
                total_blinks += 1
                total_blink_frames += blink_counter
            blink_counter = 0

    if blink_counter >= EAR_CONSEC_FRAMES:
        total_blinks += 1
        total_blink_frames += blink_counter

    blink_rate = (total_blinks / ANALYSIS_WINDOW_SECONDS) * 60
    
    avg_blink_duration = 0
    if total_blinks > 0:
        avg_blink_duration = (total_blink_frames / total_blinks) / fps

    valid_ears = [ear for ear in ear_values if ear != -1]
    if len(valid_ears) > 0:
        closed_frames = sum(1 for ear in valid_ears if ear < EAR_THRESHOLD)
        perclos = (closed_frames / len(valid_ears)) * 100
        ear_variance = np.var(valid_ears)
    else:
        perclos = 0
        ear_variance = 0
    
    return [blink_rate, avg_blink_duration, perclos, ear_variance]

def main():
    """Main function to find and process all videos based on the new structure."""
    dataset_base_dir = 'dataset' # The folder containing subject folders '01', '02', etc.
    output_csv = 'training_data.csv'
    
    video_files_to_process = []
    
    print("Scanning for video files based on filename labels...")
    if not os.path.isdir(dataset_base_dir):
        print(f"Error: Base directory '{dataset_base_dir}' not found.")
        return

    # Find all subject folders (e.g., '01', '02')
    subject_folders = [d for d in os.listdir(dataset_base_dir) if os.path.isdir(os.path.join(dataset_base_dir, d))]

    for subject_folder in subject_folders:
        subject_path = os.path.join(dataset_base_dir, subject_folder)
        for filename in os.listdir(subject_path):
            file_basename, file_ext = os.path.splitext(filename)
            video_path = os.path.join(subject_path, filename)

            if file_basename == '0':
                video_files_to_process.append((video_path, 0)) # Label 0 for Alert
            elif file_basename == '10':
                video_files_to_process.append((video_path, 1)) # Label 1 for Fatigued
            # Files named '5' are automatically ignored

    if not video_files_to_process:
        print("Error: No videos named '0.mov' or '10.mov' found in the subfolders.")
        return

    print(f"Found {len(video_files_to_process)} videos to process.")

    # Initialize Face Mesh
    mp_face_mesh = mp.solutions.face_mesh
    face_mesh = mp_face_mesh.FaceMesh(
        max_num_faces=1, refine_landmarks=True,
        min_detection_confidence=0.5, min_tracking_confidence=0.5
    )

    LEFT_EYE_INDICES = [362, 382, 381, 380, 373, 374, 390, 249, 263, 466, 388, 387, 386, 385, 384, 398]
    RIGHT_EYE_INDICES = [33, 7, 163, 144, 145, 153, 154, 155, 133, 173, 157, 158, 159, 160, 161, 246]
    
    with open(output_csv, 'w', newline='') as csvfile:
        csv_writer = csv.writer(csvfile)
        csv_writer.writerow(['Blink_Rate', 'Avg_Blink_Duration', 'PERCLOS', 'EAR_Variance', 'Fatigue_Level'])

        for video_path, label in tqdm(video_files_to_process, desc="Processing videos"):
            cap = cv2.VideoCapture(video_path)
            if not cap.isOpened():
                continue

            fps = cap.get(cv2.CAP_PROP_FPS)
            if fps == 0 or fps > 60:
                fps = 30 
            
            ANALYSIS_WINDOW_FRAMES = int(ANALYSIS_WINDOW_SECONDS * fps)
            ear_values = deque(maxlen=ANALYSIS_WINDOW_FRAMES)
            
            while cap.isOpened():
                success, image = cap.read()
                if not success:
                    break

                image_h, image_w, _ = image.shape
                image_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
                results = face_mesh.process(image_rgb)
                
                avg_ear = -1 

                if results.multi_face_landmarks:
                    face_landmarks = results.multi_face_landmarks[0].landmark
                    left_eye_coords = np.array([[face_landmarks[i].x * image_w, face_landmarks[i].y * image_h] for i in LEFT_EYE_INDICES])
                    right_eye_coords = np.array([[face_landmarks[i].x * image_w, face_landmarks[i].y * image_h] for i in RIGHT_EYE_INDICES])
                    
                    left_ear_landmarks = np.array([left_eye_coords[15], left_eye_coords[1], left_eye_coords[2], left_eye_coords[8], left_eye_coords[4], left_eye_coords[5]])
                    right_ear_landmarks = np.array([right_eye_coords[15], right_eye_coords[1], right_eye_coords[2], right_eye_coords[8], right_eye_coords[4], right_eye_coords[5]])

                    left_ear = calculate_ear(left_ear_landmarks)
                    right_ear = calculate_ear(right_ear_landmarks)
                    avg_ear = (left_ear + right_ear) / 2.0
                
                ear_values.append(avg_ear)

                if len(ear_values) == ANALYSIS_WINDOW_FRAMES:
                    features = process_video_segment(list(ear_values), fps)
                    csv_writer.writerow(features + [label])
                    # Slide the window
                    for _ in range(ANALYSIS_WINDOW_FRAMES // 2):
                        ear_values.popleft()

            cap.release()

    print(f"\nProcessing complete. Dataset saved to '{output_csv}'.")

if __name__ == '__main__':
    main()

