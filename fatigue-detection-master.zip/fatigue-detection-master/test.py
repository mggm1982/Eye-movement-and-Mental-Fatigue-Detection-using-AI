# inspect_model.py
# A diagnostic tool to analyze a saved scikit-learn model file.

import joblib
import numpy as np
import pandas as pd

MODEL_FILENAME = 'fatigue_model.joblib'

def inspect_model(filename):
    """Loads a model and prints its properties."""
    print(f"--- 🕵️‍♂️ Analyzing Model File: {filename} 🕵️‍♂️ ---")
    
    try:
        model = joblib.load(filename)
    except FileNotFoundError:
        print(f"\n[ERROR] Model file not found at '{filename}'.")
        print("Please make sure the model file is in the same directory.")
        return
    except Exception as e:
        print(f"\n[ERROR] An error occurred while loading the model: {e}")
        return

    print("\n--- 1. Model Type ---")
    model_type = model.__class__.__name__
    print(f"The model is a: '{model_type}'")
    is_classifier = hasattr(model, 'classes_')
    if is_classifier:
        print("This is a CLASSIFICATION model.")
    else:
        print("This is likely a REGRESSION model.")

    print("\n--- 2. Expected Input ---")
    try:
        num_features = model.n_features_in_
        print(f"The model was trained on {num_features} features.")
        
        feature_names = getattr(model, 'feature_names_in_', None)
        if feature_names is not None:
            print("Feature names and order:")
            for i, name in enumerate(feature_names):
                print(f"  {i+1}. {name}")
        else:
            print("Feature names are not stored in the model. You must know the order.")
            
    except AttributeError:
        print("[WARNING] Could not determine the number of input features automatically.")
        print("This might be an older or custom model.")
        return

    print("\n--- 3. Expected Output ---")
    if is_classifier:
        class_labels = model.classes_
        print(f"The model predicts one of the following classes: {class_labels}")
        print("These are the numbers the model will output.")
    else:
        print("The model will predict a continuous numerical value.")

    print("\n--- 4. Making a Test Prediction ---")
    # Create a dummy input with the correct number of features
    dummy_input = np.zeros((1, num_features))
    print(f"Creating a dummy input with shape: {dummy_input.shape}")
    
    try:
        prediction = model.predict(dummy_input)
        print(f"Successfully made a test prediction. Output: {prediction}")

        if is_classifier:
            probabilities = model.predict_proba(dummy_input)
            print("Prediction probabilities:")
            for i, class_label in enumerate(class_labels):
                print(f"  - Probability for class '{class_label}': {probabilities[0][i]*100:.2f}%")

    except Exception as e:
        print(f"\n[ERROR] Failed to make a test prediction: {e}")

    print("\n--- ✅ Analysis Complete ---")


if __name__ == '__main__':
    inspect_model(MODEL_FILENAME)