##Diagnose Model Script

import pandas as pd
import joblib
import numpy as np
import os

def diagnose():
    """Loads the model and dataset to perform diagnostics."""

    model_path = 'fatigue_model.joblib'
    data_path = 'training_data.csv'

    # --- Load Model and Data ---
    if not os.path.exists(model_path) or not os.path.exists(data_path):
        print(f"Error: Make sure '{model_path}' and '{data_path}' exist in this folder.")
        return

    model = joblib.load(model_path)
    data = pd.read_csv(data_path).dropna()
    
    features = ['Blink_Rate', 'Avg_Blink_Duration', 'PERCLOS', 'EAR_Variance']

    # --- 1. Analyze Feature Importance ---
    print("--- 1. Feature Importance ---")
    print("This shows which features the model values the most.")
    importances = model.feature_importances_
    feature_importance_map = sorted(zip(features, importances), key=lambda x: x[1], reverse=True)
    
    for feature, importance in feature_importance_map:
        print(f"{feature}: {importance*100:.2f}%")
    print("-" * 30 + "\n")


    # --- 2. Analyze Data Distribution ---
    print("--- 2. Data Distribution (Averages) ---")
    print("This shows the 'average' profile for each class in your training data.")
    # Use groupby to calculate the mean for each feature, separated by the fatigue level
    distribution = data.groupby('Fatigue_Level')[features].mean()
    print(distribution)
    print("-" * 30 + "\n")


    # --- 3. Live Test with Probabilities ---
    print("--- 3. Live Test on Your 'Alert' Request ---")
    # This is the exact data from your cURL command
    alert_test_data = {
        'Blink_Rate': [22],
        'Avg_Blink_Duration': [0.21],
        'PERCLOS': [4.0],
        'EAR_Variance': [0.0025]
    }
    alert_df = pd.DataFrame(alert_test_data)

    # Make a prediction
    prediction = model.predict(alert_df)
    
    # Get the prediction probabilities. This is the confidence score.
    # The output is an array like [[prob_for_0, prob_for_1]]
    probabilities = model.predict_proba(alert_df)

    print(f"Test Data: {alert_test_data}")
    print(f"Model Prediction: {prediction[0]} (0=Alert, 1=Fatigued)")
    print(f"Model Confidence:")
    print(f"  - Probability of being 'Alert' (0): {probabilities[0][0]*100:.2f}%")
    print(f"  - Probability of being 'Fatigued' (1): {probabilities[0][1]*100:.2f}%")
    print("-" * 30)

if __name__ == '__main__':
    diagnose()
