#First i make it clear i wrote comments for better understanding

import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, classification_report
import joblib
import os

def main():
    """Main function to train, evaluate, and save the model."""
    
    dataset_path = 'training_data.csv'

    # --- 1. Load the Dataset ---
    if not os.path.exists(dataset_path):
        print(f"Error: '{dataset_path}' not found.")
        print("Please run 'process_data.py' first to generate the dataset.")
        return

    data = pd.read_csv(dataset_path)

    print("--- Dataset Loaded ---")
    print(f"Dataset contains {len(data)} rows.")
    # Show the balance of the dataset (how many rows for each class)
    print("Class distribution:")
    print(data['Fatigue_Level'].value_counts())
    print("\n")
    
    # Handle any potential missing values by dropping them (a simple but effective strategy)
    data.dropna(inplace=True)

    # --- 2. Prepare Data for Training ---
    # 'X' contains our features (the "clues" the model will learn from)
    X = data[['Blink_Rate', 'Avg_Blink_Duration', 'PERCLOS', 'EAR_Variance']]
    # 'y' contains our target label (the "correct answer" we want the model to predict)
    y = data['Fatigue_Level']


    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )

    print("--- Data Split ---")
    print(f"Training set size: {len(X_train)} rows")
    print(f"Testing set size: {len(X_test)} rows")
    print("\n")

    # --- 4. Train the Random Forest Model ---
    print("--- Training Model ---")
    # Initialize the classifier. 
    # `n_estimators=100` means our "forest" will be made of 100 individual "decision trees".
    # `n_jobs=-1` tells the model to use all available CPU cores to speed up training.
    model = RandomForestClassifier(n_estimators=100, random_state=42, n_jobs=-1)

    # This is the core training step. The model "studies" the training data.
    model.fit(X_train, y_train)
    print("Model training complete.")
    print("\n")

    # --- 5. Evaluate the Model ---
    print("--- Evaluating Model on Unseen Test Data ---")
    # The model now takes its "final exam" by making predictions on the test data it has never seen.
    y_pred = model.predict(X_test)

    # Calculate and print the overall accuracy
    accuracy = accuracy_score(y_test, y_pred)
    print(f"Model Accuracy on Test Set: {accuracy * 100:.2f}%")

    # Print a more detailed report showing performance for each class
    print("\nClassification Report:")
    print(classification_report(y_test, y_pred, target_names=['Alert (0)', 'Fatigued (1)']))

    # --- 6. Save the Trained Model ---
    model_filename = 'fatigue_model.joblib'
    joblib.dump(model, model_filename)
    print(f"--- Model Saved ---")
    print(f"The trained model has been saved as '{model_filename}'.")
    print("This file is the 'brain' of our application.")

if __name__ == '__main__':
    main()
